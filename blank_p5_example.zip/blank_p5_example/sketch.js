function setup() {
  createCanvas(600, 600);
}

function draw() {
}